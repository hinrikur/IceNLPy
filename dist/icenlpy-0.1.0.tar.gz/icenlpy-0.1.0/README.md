# IceNL*Py*

A python wrapper for the IceNLP toolkit.