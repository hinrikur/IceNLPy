./icestagger.sh -modelfile ./models/otb.bin -lang is -plain -icemorphy 1 -tag sentences.txt
