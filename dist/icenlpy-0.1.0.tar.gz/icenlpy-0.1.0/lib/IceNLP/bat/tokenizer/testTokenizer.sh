./tokenize.sh -i test.txt -o test.out -if 3 -of 1
