rule_hand_written_utf8.txt contains handwritten lemmatisation rules
rule_database_utf8.txt contains automatically generated lemmatisation rules
./makeRules.sh combines these two files and generates the rule_database_utf8.dat file needed by Lemmald

