import sys
import logging
from pathlib import Path
from os.path import exists

logger = logging.getLogger(__name__)

# Assuming 'icenlpy' is your package name and the JAR is in the 'resources' subdirectory
try:
    package_dir = Path(__file__).parent
    ice_nlp_dir = package_dir / "resources/IceNLP/"
    jar_path = ice_nlp_dir / "dist/IceNLPCore.jar"
    # Possibly store the JAR path in a package-level variable for easy access
    jar_path = jar_path.resolve()
    assert exists(jar_path)
    JAR_PATH = str(jar_path)
    JAR_FOUND = True
    logger.debug(f"IceNLP JAR file is located at: {JAR_PATH}")
except Exception as e:
    print(
        f"Failed to locate IceNLPCore.jar within the icenlpy package: {e}",
        file=sys.stderr,
    )
    # Depending on your package's requirements, you might want to halt further execution
    # or simply warn the user and allow for manual configuration later.
    JAR_PATH = None  # Set to None or consider raising an error
    JAR_FOUND = False
