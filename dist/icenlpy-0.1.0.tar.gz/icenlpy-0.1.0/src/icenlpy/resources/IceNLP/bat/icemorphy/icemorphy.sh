java -Xmx256M -classpath ../../dist/IceNLPCore.jar is.iclt.icenlp.runner.RunIceMorphy $1 $2
