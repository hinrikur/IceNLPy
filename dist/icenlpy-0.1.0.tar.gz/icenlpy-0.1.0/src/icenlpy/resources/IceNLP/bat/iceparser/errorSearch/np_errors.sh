java -Xmx256M -classpath ../../../dist/IceNLPCore.jar is.iclt.icenlp.core.iceparser.NP_errors $1 > $2
