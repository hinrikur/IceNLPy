./icestagger.sh -modelfile ./models/otbBIN.bin -lang is -plain  -tag sentences.txt
