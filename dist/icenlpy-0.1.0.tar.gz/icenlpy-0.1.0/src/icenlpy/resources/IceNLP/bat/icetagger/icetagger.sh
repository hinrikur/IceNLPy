java -Xmx768M -classpath ../../dist/IceNLPCore.jar is.iclt.icenlp.runner.RunIceTagger $*
