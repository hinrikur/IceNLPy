cat test.txt | ../icetagger/icetagger.sh  | ../iceparser/iceparser.sh -f -l > parse.out
