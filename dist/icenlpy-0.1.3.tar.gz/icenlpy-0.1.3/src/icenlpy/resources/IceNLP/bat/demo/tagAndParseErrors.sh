cat testErrors.txt | ../icetagger/icetagger.sh  | ../iceparser/iceparser.sh -f -l -e > parse.out
