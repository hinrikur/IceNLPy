./tokenize.sh -i test2.txt -o test2.out -if 0 -of 2
