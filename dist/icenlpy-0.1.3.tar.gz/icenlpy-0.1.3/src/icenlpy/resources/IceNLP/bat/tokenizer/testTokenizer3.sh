./tokenize.sh -i test3.txt -o test3.out -if 1 -of 2
