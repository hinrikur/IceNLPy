java -Xmx1280M -classpath ../../dist/IceNLPCore.jar is.iclt.icenlp.runner.RunTriTagger $*
