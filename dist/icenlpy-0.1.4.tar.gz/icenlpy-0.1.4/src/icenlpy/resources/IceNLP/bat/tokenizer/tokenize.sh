java -classpath ../../dist/IceNLPCore.jar is.iclt.icenlp.runner.RunTokenizer $*
