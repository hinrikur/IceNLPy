java -Xmx256M -classpath ../../../dist/IceNLPCore.jar is.iclt.icenlp.core.iceparser.PP_errors $1 > $2
