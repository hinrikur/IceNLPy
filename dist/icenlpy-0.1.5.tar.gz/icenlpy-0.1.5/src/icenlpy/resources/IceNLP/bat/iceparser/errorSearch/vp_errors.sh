java -Xmx256M -classpath ../../../dist/IceNLPCore.jar is.iclt.icenlp.core.iceparser.VP_errors $1 > $2
