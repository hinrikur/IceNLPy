java -classpath ../../dist/IceNLPCore.jar:../../lib/segment-1.3.3.jar:../../lib/commons-io-1.4.jar:../../lib/commons-logging-1.1.1.jar is.iclt.icenlp.core.tokenizer.SrxSegmentizer $1 $2
